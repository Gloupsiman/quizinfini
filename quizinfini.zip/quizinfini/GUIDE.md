# 🚀 Guide de mise en ligne — QuizInfini
## 100% gratuit, 10 minutes chrono

---

## ÉTAPE 1 — Crée un compte GitHub (gratuit)
1. Va sur https://github.com
2. Clique "Sign up" et crée ton compte

---

## ÉTAPE 2 — Upload les fichiers
1. Une fois connecté, clique sur le "+" en haut à droite
2. Choisis "New repository"
3. Nom : `quizinfini`
4. Coche "Public"
5. Clique "Create repository"
6. Clique "uploading an existing file"
7. Glisse tous les fichiers du dossier quizinfini/ (index.html, manifest.json, sw.js, et le dossier icons/)
8. Clique "Commit changes"

---

## ÉTAPE 3 — Mets en ligne sur Vercel (gratuit)
1. Va sur https://vercel.com
2. Clique "Sign up" → connecte-toi avec ton compte GitHub
3. Clique "Add New Project"
4. Sélectionne ton repository "quizinfini"
5. Clique "Deploy"
6. ✅ En 30 secondes ton app est en ligne !

Ton lien sera : https://quizinfini.vercel.app

---

## ÉTAPE 4 — Partage et gagne des utilisateurs
- Partage le lien sur TikTok, Instagram, WhatsApp
- Poste sur des groupes Facebook de culture générale
- Partage sur Reddit r/france ou r/quiz

---

## Pour installer l'app sur téléphone (sans store)
### iPhone :
1. Ouvre le lien dans Safari
2. Appuie sur le bouton Partager (carré avec flèche)
3. Choisis "Sur l'écran d'accueil"
4. L'app apparaît comme une vraie app !

### Android :
1. Ouvre le lien dans Chrome
2. Une bannière "Installer" apparaît automatiquement
3. Ou appuie sur les 3 points → "Ajouter à l'écran d'accueil"

---

## Monétisation (quand tu auras des visiteurs)
1. Crée un compte Google AdSense sur https://adsense.google.com
2. Ajoute 2 lignes de code dans index.html (je peux le faire pour toi)
3. Tu gagnes de l'argent à chaque publicité vue

---

## Structure des fichiers
```
quizinfini/
├── index.html       ← L'app complète
├── manifest.json    ← Config PWA (icône, nom...)
├── sw.js            ← Mode hors-ligne
└── icons/
    ├── icon-192.png ← Icône téléphone
    └── icon-512.png ← Icône haute résolution
```
